package mooc.vandy.java4android.gate.logic;

import java.util.Random;

import mooc.vandy.java4android.gate.ui.OutputInterface;

/**
 * This class uses your Gate class to fill the corral with snails.  We
 * have supplied you will the code necessary to execute as an app.
 * You must fill in the missing logic below.
 */
public class FillTheCorral {
    /**
     * Reference to the OutputInterface.
     */
    private OutputInterface mOut;

    /**
     * Constructor initializes the field.
     */
    FillTheCorral(OutputInterface out) {
        mOut = out;
    }


    public void setCorralGates(Gate[] gates,Random selectDirection) {
        for (Gate gate: gates) {
            int randomValue = selectDirection.nextInt(3) - 1;
            gate.open(randomValue);
        }
    }

    public boolean anyCorralAvailable(Gate[] corral) {
        for (Gate gate:corral) {
            if (gate.getSwingDirection() == Gate.IN)
                return true;
        }
        return false;
    }

    public int corralSnails(Gate[] corral,Random rand) {
        int snailsInPasture = 5;
        int attempts = 0;
        for (int i = 0; i < corral.length; ++i) {
            mOut.println("Gate " + i +": " + corral[i].toString() + ".");
        }

        while(snailsInPasture > 0 ) {
            int currentGateIndex = rand.nextInt(corral.length);
            int currentSnails = rand.nextInt(snailsInPasture) + 1;
            Gate currentGate = corral[currentGateIndex];
            if (!currentGate.isLocked()) {
                currentSnails = currentGate.thru(currentSnails);
                snailsInPasture -= currentSnails;
            }
            mOut.println(Math.abs(currentSnails) + " are trying to move through corral "
                + currentGateIndex);
            attempts++;
        }
        mOut.println("It took " + attempts + " attempts to corral all of the snails.");
        return attempts;
    }
}
